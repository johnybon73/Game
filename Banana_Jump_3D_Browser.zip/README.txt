BANANA JUMP 3D — BROWSER VERSION

Open index.html in a modern browser with internet access.
Tap anywhere to jump. Avoid the green obstacles.
If the file opens as text instead of a game, upload the folder to a static web host (for example itch.io or GitHub Pages) and open the resulting HTTPS link.

This browser version is a standalone recreation of the original Godot prototype using WebGL/Three.js, so it does not require Godot or a Mac.
